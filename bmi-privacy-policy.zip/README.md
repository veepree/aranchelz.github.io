# BMI Calculator Privacy Policy

This repository contains the Privacy Policy page for the BMI Calculator app.

- 🧱 Built with: HTML + CSS  
- 🌐 Compatible with GitHub Pages  
- 📅 Last Updated: November 8, 2025  
- 👤 Developer: Aranchelz
